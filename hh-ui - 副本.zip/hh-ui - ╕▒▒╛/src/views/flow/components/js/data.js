// 测试数据
const graphData = {
  "nodes": [
    {
      "text": {
        "value": "开始",
        "x": "160",
        "y": "280"
      },
      "properties": {},
      "type": "start",
      "id": "1",
      "x": "160",
      "y": "280"
    },
    {
      "text": {
        "value": "组长审批",
        "x": "320",
        "y": "280"
      },
      "properties": {
        "permissionFlag": "role:1,role:3"
      },
      "type": "between",
      "id": "2",
      "x": "320",
      "y": "280"
    },
    {
      "text": {},
      "properties": {
        "permissionFlag": "role:1,role:3"
      },
      "type": "between",
      "id": "3",
      "x": "520",
      "y": "280"
    },
    {
      "text": {
        "value": "",
        "x": "700",
        "y": "280"
      },
      "properties": {},
      "type": "serial",
      "id": "4",
      "x": "700",
      "y": "280"
    },
    {
      "text": {
        "value": "大组长审批",
        "x": "920",
        "y": "180"
      },
      "properties": {
        "permissionFlag": "role:1,role:3"
      },
      "type": "between",
      "id": "5",
      "x": "920",
      "y": "180"
    },
    {
      "text": {
        "value": "部门经理审批",
        "x": "1140",
        "y": "180"
      },
      "properties": {
        "permissionFlag": "role:1,role:3"
      },
      "type": "between",
      "id": "6",
      "x": "1140",
      "y": "180"
    },
    {
      "text": {
        "value": "董事长审批",
        "x": "920",
        "y": "360"
      },
      "properties": {
        "permissionFlag": "role:1,role:3"
      },
      "type": "between",
      "id": "7",
      "x": "920",
      "y": "360"
    },
    {
      "text": {
        "value": "结束",
        "x": "1380",
        "y": "280"
      },
      "properties": {},
      "type": "end",
      "id": "8",
      "x": "1380",
      "y": "280"
    }
  ],
  "edges": [
    {
      "text": {
        "value": "通过",
        "x": "225",
        "y": "280"
      },
      "properties": {
        "skipCondition": null,
        "skipType": "PASS"
      },
      "id": "1163988534898593794",
      "type": "skip",
      "sourceNodeId": "1",
      "targetNodeId": "2",
      "pointsList": [
        {
          "x": 180,
          "y": 280
        },
        {
          "x": 270,
          "y": 280
        }
      ],
      "startPoint": {
        "x": 180,
        "y": 280
      },
      "endPoint": {
        "x": 270,
        "y": 280
      }
    },
    {
      "text": {
        "value": "通过",
        "x": "420",
        "y": "280"
      },
      "properties": {
        "skipCondition": null,
        "skipType": "PASS"
      },
      "id": "1163988534898593796",
      "type": "skip",
      "sourceNodeId": "2",
      "targetNodeId": "3",
      "pointsList": [
        {
          "x": 370,
          "y": 280
        },
        {
          "x": 470,
          "y": 280
        }
      ],
      "startPoint": {
        "x": 370,
        "y": 280
      },
      "endPoint": {
        "x": 470,
        "y": 280
      }
    },
    {
      "text": {
        "value": "通过",
        "x": "625",
        "y": "280"
      },
      "properties": {
        "skipCondition": null,
        "skipType": "PASS"
      },
      "id": "1163988534898593798",
      "type": "skip",
      "sourceNodeId": "3",
      "targetNodeId": "4",
      "pointsList": [
        {
          "x": 570,
          "y": 280
        },
        {
          "x": 680,
          "y": 280
        }
      ],
      "startPoint": {
        "x": 570,
        "y": 280
      },
      "endPoint": {
        "x": 680,
        "y": 280
      }
    },
    {
      "text": {
        "value": "请假天数小于4",
        "x": "805",
        "y": "182"
      },
      "properties": {
        "skipCondition": "请假天数小于4",
        "skipType": "PASS"
      },
      "id": "1163988534898593800",
      "type": "skip",
      "sourceNodeId": "4",
      "targetNodeId": "5",
      "pointsList": [
        {
          "x": 720,
          "y": 280
        },
        {
          "x": 740,
          "y": 280
        },
        {
          "x": 740,
          "y": 182
        },
        {
          "x": 870,
          "y": 182
        }
      ],
      "startPoint": {
        "x": 720,
        "y": 280
      },
      "endPoint": {
        "x": 870,
        "y": 182
      }
    },
    {
      "text": {
        "value": "请假天数大于等于4",
        "x": "810",
        "y": "360"
      },
      "properties": {
        "skipCondition": "请假天数大于等于4",
        "skipType": "PASS"
      },
      "id": "1163988534898593801",
      "type": "skip",
      "sourceNodeId": "4",
      "targetNodeId": "7",
      "pointsList": [
        {
          "x": 720,
          "y": 280
        },
        {
          "x": 750,
          "y": 280
        },
        {
          "x": 750,
          "y": 360
        },
        {
          "x": 870,
          "y": 360
        }
      ],
      "startPoint": {
        "x": 720,
        "y": 280
      },
      "endPoint": {
        "x": 870,
        "y": 360
      }
    },
    {
      "text": {
        "value": "通过",
        "x": "1030",
        "y": "180"
      },
      "properties": {
        "skipCondition": null,
        "skipType": "PASS"
      },
      "id": "1163988534898593803",
      "type": "skip",
      "sourceNodeId": "5",
      "targetNodeId": "6",
      "pointsList": [
        {
          "x": 970,
          "y": 180
        },
        {
          "x": 1090,
          "y": 180
        }
      ],
      "startPoint": {
        "x": 970,
        "y": 180
      },
      "endPoint": {
        "x": 1090,
        "y": 180
      }
    },
    {
      "text": {
        "value": "通过",
        "x": "1285",
        "y": "180"
      },
      "properties": {
        "skipCondition": null,
        "skipType": "PASS"
      },
      "id": "1163988534898593805",
      "type": "skip",
      "sourceNodeId": "6",
      "targetNodeId": "8",
      "pointsList": [
        {
          "x": 1190,
          "y": 180
        },
        {
          "x": 1380,
          "y": 180
        },
        {
          "x": 1380,
          "y": 260
        }
      ],
      "startPoint": {
        "x": 1190,
        "y": 180
      },
      "endPoint": {
        "x": 1380,
        "y": 260
      }
    },
    {
      "text": {
        "value": "驳回",
        "x": "1030",
        "y": "110"
      },
      "properties": {
        "skipCondition": null,
        "skipType": "REJECT"
      },
      "id": "1163988534898593806",
      "type": "skip",
      "sourceNodeId": "6",
      "targetNodeId": "5",
      "pointsList": [
        {
          "x": 1140,
          "y": 140
        },
        {
          "x": 1140,
          "y": 110
        },
        {
          "x": 920,
          "y": 110
        },
        {
          "x": 920,
          "y": 140
        }
      ],
      "startPoint": {
        "x": 1140,
        "y": 140
      },
      "endPoint": {
        "x": 920,
        "y": 140
      }
    },
    {
      "text": {
        "value": "通过",
        "x": "1175",
        "y": "360"
      },
      "properties": {
        "skipCondition": null,
        "skipType": "PASS"
      },
      "id": "1163988534898593809",
      "type": "skip",
      "sourceNodeId": "7",
      "targetNodeId": "8",
      "pointsList": [
        {
          "x": 970,
          "y": 360
        },
        {
          "x": 1380,
          "y": 360
        },
        {
          "x": 1380,
          "y": 300
        }
      ],
      "startPoint": {
        "x": 970,
        "y": 360
      },
      "endPoint": {
        "x": 1380,
        "y": 300
      }
    }
  ],
  "flowCode": "leaveFlow-serial2",
  "flowName": "请假流程-串行2",
  "version": "1.0",
  "fromCustom": "N",
  "fromPath": "test/leave/approve"
};

export default graphData
