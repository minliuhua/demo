<template>
  <div>
    <el-form ref="form" :model="form" label-width="120px" size="small">
      <slot name="form-item-task-skipType" :model="form" field="skipType">
        <el-form-item label="跳转类型">
          <el-select v-model="form.skipType">
            <el-option sel label="审批通过" value="PASS"/>
            <el-option label="驳回" value="REJECT"/>
          </el-select>
        </el-form-item>
      </slot>
      <slot name="form-item-task-skipCondition" :model="form" field="skipCondition">
        <el-form-item label="跳转条件">
          <el-input v-model="form.skipCondition" placeholder="跳转条件"/>
        </el-form-item>
      </slot>
    </el-form>
  </div>
</template>

<script>
import {listRole} from "@/api/system/role";
import {listUser} from "@/api/system/user";
import {listDept} from "@/api/system/dept";

export default {
  name: "Between",
  props: {
    value: {
      type: Object,
      default () {
        return {}
      }
    },
  },
  data () {
    return {
      form: this.value,
      // 是否禁用表单
      disabled: false,
      attrKey: '',
      field: this.value.field || {},
    }
  },
  created() {
    if (this.$route.query.disabled == 'true') {
      this.disabled = true
    }
  },
  methods: {
  }
}
</script>

<style scoped>

</style>
