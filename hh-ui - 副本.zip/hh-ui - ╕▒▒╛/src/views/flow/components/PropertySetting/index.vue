<template>
  <div>
    <el-drawer
      ref="drawer"
      :title="title"
      destroy-on-close
      :visible.sync="drawer"
      direction="rtl"
      :append-to-body="true"
      :before-close="handleClose">
      <component :is="node?node.type:''" v-model="form" >
        <template v-slot:[key]="data" v-for="(item, key) in $scopedSlots">
          <slot :name="key" v-bind="data || {}"></slot>
        </template>
      </component>
    </el-drawer>
  </div>
</template>

<script>
import Start from './start.vue'
import Between from './between.vue'
import Serial from './serial.vue'
import Parallel from './parallel.vue'
import End from './end.vue'
import Skip from './skip.vue'
import {skipText} from "@/views/flow/components/js/tool";

export default {
  components: {
    Start,
    Between,
    Serial,
    Parallel,
    End,
    Skip,
  },
  props: {
    value: {
      type: Object,
      default () {
        return {}
      }
    },
    node: {
      type: Object,
      default () {
        return {}
      }
    },
    lf: {
      type: Object,
      default () {
        return null
      }
    },
  },
  data () {
    return {
      drawer: false,
      form: {},
      objId: undefined
    }
  },
  watch: {
    node (n) {
      if (n) {
        this.objId = n.id
        if (n.type === 'skip') {
          this.form = {
            skipType: n.properties.skipType,
            skipCondition: n.properties.skipCondition,
          }
        } else {
          this.form = {
            nodeType: n.type,
            nodeCode: n.id,
            nodeName: n.text instanceof Object ? n.text.value : n.text,
            ...n.properties,
            permissionFlag: n.properties.permissionFlag ? n.properties.permissionFlag.split(","): [],
          }
        }
      }
    },
    'form.nodeCode' (n, o) {
      // 监听节点编码变量并更新
      if (n && o) {
        if (['skip'].includes(this.node.type)) {
          if (!this.lf.getEdgeModelById(n)) {
            this.lf.changeEdgeId(o, n)
          }
        } else {
          if (!this.lf.getNodeModelById(n)) {
            this.lf.changeNodeId(o, n)
          }
        }
        this.objId = n
      }
    },
    'form.skipType' (n) {
      // 监听跳转名称变化并更新
      this.lf.updateText(this.objId, skipText(n))
      // 监听跳转属性变化并更新
      this.lf.setProperties(this.objId, {
        skipType: n
      })
    },
    'form.nodeName' (n) {
      debugger
      // 监听节点名称变化并更新
      this.lf.updateText(this.objId, n)
    },
    'form.permissionFlag' (n) {
      // 监听节点属性变化并更新
      this.lf.setProperties(this.objId, {
        permissionFlag: n.join()
      })
    },
    'form.skipCondition' (n) {
      // 监听跳转名称变化并更新
      this.lf.updateText(this.objId, n)
      // 监听跳转属性变化并更新
      this.lf.setProperties(this.objId, {
        skipCondition: n
      })
    },
  },
  computed: {
    title () {
      if (this.node && this.node.type === 'skip') {
        return '设置边属性'
      } else if (this.node && this.node.type === 'serial') {
        return '设置串行网关属性'
      } else if (this.node && this.node.type === 'parallel') {
        return '设置并行网关属性'
      } else if (this.node && this.node.type === 'start') {
        return '设置开始属性'
      } else if (this.node && this.node.type === 'end') {
        return '设置结束属性'
      }
      return '设置中间属性'
    }
  },
  methods: {
    show () {
      this.drawer = true
    },
    handleClose () {
      this.drawer = false
    }
  }
}
</script>

<style scoped>
.el-drawer__container ::-webkit-scrollbar {
  display: none;
}
</style>
