<template>
  <div>
    <el-form ref="form" :model="form" label-width="120px" size="small">
      <slot name="form-item-task-name" :model="form" field="nodeCode">
        <el-form-item label="节点编码">
          <el-input v-model="form.nodeCode" :disabled="disabled"></el-input>
        </el-form-item>
      </slot>
      <slot name="form-item-task-name" :model="form" field="nodeName">
        <el-form-item label="节点名称">
          <el-input v-model="form.nodeName" :disabled="disabled"></el-input>
        </el-form-item>
      </slot>
    </el-form>
  </div>
</template>

<script>

export default {
  name: "Parallel",
  props: {
    value: {
      type: Object,
      default () {
        return {}
      }
    },
  },
  data () {
    return {
      form: this.value,
      // 是否禁用表单
      disabled: false,
      field: this.value.field || {},
    }
  },
  watch: {
    form: {
      handler (n) {
        this.$emit('change', n)
      },
      deep: true
    }
  },
  created() {
    if (this.$route.query.disabled == 'true') {
      this.disabled = true
    }
  },
  methods: {

  }
}
</script>

<style scoped>

</style>
