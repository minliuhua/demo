<template>
  <div id="app">
    <Design_new />
  </div>
</template>

<script>
import Design_new from "./views/flow/definition/design_new";


export default {
  name: "App",
  components: { Design_new,},
};
</script>
<style scoped>
#app .theme-picker {
  display: none;
}
</style>
